Ext.define('ExecDashboard.model.Kpi', {
    extend: 'ExecDashboard.model.Base',

    fields: [
        'category',
        'name',
        'data1',
        'data2',
        'data3',
        'data4',
        'data5'
    ]
});
